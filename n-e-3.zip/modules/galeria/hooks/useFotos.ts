'use client';

import { useState, useCallback } from 'react';
import { Photo, Album } from '../types';
import {
  getGaleriaItems,
  uploadPhoto as uploadPhotoAction,
  uploadAlbum as uploadAlbumAction,
  updatePhoto as updatePhotoAction,
  updateAlbum as updateAlbumAction,
  deletePhoto as deletePhotoAction,
  deleteAlbum as deleteAlbumAction,
} from '../actions';

export function useFotos(initialPhotos: Photo[], initialAlbums: Album[]) {
  const [photos, setPhotos] = useState<Photo[]>(initialPhotos);
  const [albums, setAlbums] = useState<Album[]>(initialAlbums);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    const { photos: p, albums: a } = await getGaleriaItems();
    setPhotos(p);
    setAlbums(a);
    setLoading(false);
  }, []);

  const uploadFoto = useCallback(async (file: File, title: string, caption: string) => {
    const fd = new FormData();
    fd.append('file', file);
    fd.append('title', title);
    fd.append('caption', caption);
    const result = await uploadPhotoAction(fd);
    if (result.success) await refresh();
    return result;
  }, [refresh]);

  const uploadAlbum = useCallback(async (files: File[], title: string, caption: string) => {
    const fd = new FormData();
    files.forEach(f => fd.append('files', f));
    fd.append('title', title);
    fd.append('caption', caption);
    const result = await uploadAlbumAction(fd);
    if (result.success) await refresh();
    return result;
  }, [refresh]);

  const editFoto = useCallback(async (id: string, title: string, caption: string) => {
    const result = await updatePhotoAction(id, title, caption);
    if (result.success) {
      setPhotos(prev => prev.map(p => p.id === id ? { ...p, title, caption } : p));
      setAlbums(prev => prev.map(a => ({
        ...a,
        photos: a.photos.map(p => p.id === id ? { ...p, title, caption } : p),
      })));
    }
    return result;
  }, []);

  const editAlbum = useCallback(async (id: string, title: string, caption: string) => {
    const result = await updateAlbumAction(id, title, caption);
    if (result.success) {
      setAlbums(prev => prev.map(a => a.id === id ? { ...a, title, caption } : a));
    }
    return result;
  }, []);

  const deleteFoto = useCallback(async (id: string) => {
    const result = await deletePhotoAction(id);
    if (result.success) {
      setPhotos(prev => prev.filter(p => p.id !== id));
      setAlbums(prev =>
        prev
          .map(a => ({ ...a, photos: a.photos.filter(p => p.id !== id) }))
          .filter(a => a.photos.length > 0)
      );
    }
    return result;
  }, []);

  const deleteAlbum = useCallback(async (id: string) => {
    const result = await deleteAlbumAction(id);
    if (result.success) setAlbums(prev => prev.filter(a => a.id !== id));
    return result;
  }, []);

  return {
    photos, albums, loading,
    refresh, uploadFoto, uploadAlbum,
    editFoto, editAlbum, deleteFoto, deleteAlbum,
  };
}
