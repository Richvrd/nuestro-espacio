'use client';

import { useState } from 'react';
import { useFotos } from '@/modules/galeria/hooks/useFotos';
import { Photo, Album } from '@/modules/galeria/types';
import { FotoCard } from './FotoCard';
import { AlbumCard } from './AlbumCard';
import { FotoModal } from './FotoModal';
import { AlbumModal } from './AlbumModal';
import { UploadModal } from './UploadModal';
import { EmptyState } from '@/components/ui/EmptyState';

interface GaleriaGridProps {
  initialPhotos: Photo[];
  initialAlbums: Album[];
}

export function GaleriaGrid({ initialPhotos, initialAlbums }: GaleriaGridProps) {
  const {
    photos, albums,
    uploadFoto, uploadAlbum,
    editFoto, editAlbum, deleteFoto, deleteAlbum,
  } = useFotos(initialPhotos, initialAlbums);

  const [uploadOpen, setUploadOpen] = useState(false);
  const [openPhoto, setOpenPhoto] = useState<Photo | null>(null);
  const [openAlbum, setOpenAlbum] = useState<Album | null>(null);

  const handleDeletePhotos = async (ids: string[]) => {
    for (const id of ids) await deleteFoto(id);
  };

  // Merge fotos y álbumes ordenados por created_at
  const total = photos.length + albums.length;

  return (
    <>
      <div className="gallery-grid">
        {total === 0 && (
          <EmptyState
            icon="📸"
            title="Aún no hay fotos"
            subtitle="sean los primeros en subir un recuerdo"
          />
        )}

        {/* Fotos individuales */}
        {photos.map((photo, i) => (
          <FotoCard key={photo.id} photo={photo} index={i} onOpen={() => setOpenPhoto(photo)} />
        ))}

        {/* Álbumes */}
        {albums.map((album, i) => (
          <AlbumCard key={album.id} album={album} index={i} onOpen={() => setOpenAlbum(album)} />
        ))}

        {/* Botón subir */}
        <button className="upload-zone" onClick={() => setUploadOpen(true)}>
          <span className="upload-icon">+</span>
          <span className="upload-label">Subir<br />foto</span>
        </button>
      </div>

      {/* Modales */}
      {uploadOpen && (
        <UploadModal
          onClose={() => setUploadOpen(false)}
          onUploadPhoto={uploadFoto}
          onUploadAlbum={uploadAlbum}
        />
      )}

      {openPhoto && (
        <FotoModal
          photo={openPhoto}
          onClose={() => setOpenPhoto(null)}
          onEdit={editFoto}
          onDelete={deleteFoto}
        />
      )}

      {openAlbum && (
        <AlbumModal
          album={openAlbum}
          onClose={() => setOpenAlbum(null)}
          onEditAlbum={editAlbum}
          onDeletePhotos={handleDeletePhotos}
          onDeleteAlbum={deleteAlbum}
        />
      )}
    </>
  );
}
