'use client';

import { useState, useEffect, useCallback } from 'react';
import { Photo } from '../types';

interface FotoModalProps {
  photo: Photo;
  onClose: () => void;
  onEdit: (id: string, title: string, caption: string) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}

export function FotoModal({ photo, onClose, onEdit, onDelete }: FotoModalProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(photo.title || photo.caption);
  const [editCaption, setEditCaption] = useState(photo.caption);

  const formattedDate = new Date(photo.created_at).toLocaleDateString('es-ES', {
    day: 'numeric', month: 'long', year: 'numeric',
  });

  const handleKey = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
  }, [onClose]);

  useEffect(() => {
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [handleKey]);

  const handleSave = async () => {
    await onEdit(photo.id, editTitle, editCaption);
    setEditing(false);
  };

  const handleDelete = async () => {
    await onDelete(photo.id);
    onClose();
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="foto-modal-box" onClick={e => e.stopPropagation()}>

        {/* Imagen */}
        <div className="foto-modal-img-wrap">
          {photo.url
            ? <img src={photo.url} alt={photo.title} className="foto-modal-img" />
            : <div className="foto-modal-placeholder" style={{ background: photo.bg_gradient || 'linear-gradient(135deg,#2a1f35,#1a1924)' }}>{photo.emoji || '📷'}</div>
          }
        </div>

        {/* Sidebar derecha */}
        <div className="foto-modal-sidebar">
          <div className="foto-modal-sidebar-top">
            <button className="modal-close-btn" onClick={onClose}>✕</button>
          </div>

          {editing ? (
            <div className="foto-modal-edit">
              <input
                className="form-input"
                value={editTitle}
                onChange={e => setEditTitle(e.target.value)}
                placeholder="título"
                autoFocus
              />
              <input
                className="form-input"
                value={editCaption}
                onChange={e => setEditCaption(e.target.value)}
                placeholder="descripción"
              />
              <div className="modal-actions" style={{ marginTop: 'auto' }}>
                <button className="btn btn-ghost" onClick={() => setEditing(false)}>cancelar</button>
                <button className="btn btn-primary" onClick={handleSave}>guardar</button>
              </div>
            </div>
          ) : (
            <div className="foto-modal-info">
              <h2 className="foto-modal-title">{photo.title || photo.caption}</h2>
              {photo.caption && photo.caption !== photo.title && (
                <p className="foto-modal-caption">{photo.caption}</p>
              )}
              <span className="foto-modal-date">{formattedDate}</span>

              {/* Tres puntitos */}
              <div className="foto-modal-menu-wrap">
                <button className="three-dots-btn" onClick={() => setMenuOpen(o => !o)}>···</button>
                {menuOpen && (
                  <div className="three-dots-menu">
                    <button onClick={() => { setEditing(true); setMenuOpen(false); }}>editar</button>
                    <button className="delete-opt" onClick={handleDelete}>eliminar</button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
